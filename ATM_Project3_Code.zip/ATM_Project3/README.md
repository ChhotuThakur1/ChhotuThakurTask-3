# Java ATM Interface — DecodeLabs Project 3

## How to Run
```
javac *.java
java Main
```

Default test account:
- Account Number: ACC1001
- PIN: 1234
- Starting Balance: $5000.00

## Files
- `BankAccount.java` — encapsulated account data + business rules (deposit, withdraw, balance)
- `ATM.java` — menu-driven interface, handles Scanner input and validation
- `Main.java` — entry point

## Key Concepts Demonstrated
- Classes & Objects
- Encapsulation (private fields, public getters/mutators)
- Separation of Concerns (UI layer vs. logic layer)
- Input validation (hasNextInt/hasNextDouble to prevent crashes)
- Business rule enforcement (no overdraft, no negative deposits)
