/**
 * BankAccount.java
 * ------------------
 * Represents a bank account with strict encapsulation.
 * This class knows NOTHING about the console, Scanner, or menus.
 * It only handles data and business rules (the "Vault" layer).
 */
public class BankAccount {

    // Private fields -> data hiding (no outside class can touch these directly)
    private String accountNumber;
    private String accountHolderName;
    private int pin;
    private double balance;

    // Constructor
    public BankAccount(String accountNumber, String accountHolderName, int pin, double initialBalance) {
        this.accountNumber = accountNumber;
        this.accountHolderName = accountHolderName;
        this.pin = pin;
        this.balance = initialBalance;
    }

    // Getter - read-only access to balance
    public double getBalance() {
        return balance;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public String getAccountHolderName() {
        return accountHolderName;
    }

    // Used only for authentication, never exposed directly to menus
    public boolean validatePin(int enteredPin) {
        return this.pin == enteredPin;
    }

    /**
     * Deposit method - mutator/security checkpoint.
     * Rejects invalid (negative or zero) amounts before touching balance.
     */
    public boolean deposit(double amount) {
        if (amount <= 0) {
            return false; // invalid amount, transaction rejected
        }
        balance += amount;
        return true;
    }

    /**
     * Withdraw method - mutator/security checkpoint.
     * Enforces business rules: amount must be positive AND
     * must not exceed the current balance (no overdraft allowed).
     */
    public boolean withdraw(double amount) {
        if (amount <= 0) {
            return false; // invalid amount
        }
        if (amount > balance) {
            return false; // insufficient funds
        }
        balance -= amount;
        return true;
    }
}
