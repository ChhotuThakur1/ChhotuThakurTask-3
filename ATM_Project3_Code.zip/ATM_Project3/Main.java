/**
 * Main.java
 * ----------
 * DecodeLabs Java Programming - Project 3: ATM Interface
 * Entry point of the application. Creates a sample BankAccount
 * and hands control over to the ATM interface.
 */
public class Main {
    public static void main(String[] args) {
        // Sample account: accountNumber, holderName, PIN, initial balance
        BankAccount account = new BankAccount("ACC1001", "John Doe", 1234, 5000.00);

        ATM atm = new ATM(account);
        atm.start();
    }
}
