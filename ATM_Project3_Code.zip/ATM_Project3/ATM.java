import java.util.Scanner;

/**
 * ATM.java
 * ---------
 * Handles the human-facing side of the system: menus, Scanner input,
 * and input validation. Delegates all money logic to BankAccount.
 * This is the "Lobby / Interface" layer - it never touches balance directly.
 */
public class ATM {

    private BankAccount account;
    private Scanner scanner;

    public ATM(BankAccount account) {
        this.account = account;
        this.scanner = new Scanner(System.in);
    }

    // Entry point for the whole session
    public void start() {
        System.out.println("=======================================");
        System.out.println(" Welcome, " + account.getAccountHolderName() + "!");
        System.out.println("=======================================");

        if (!authenticate()) {
            System.out.println("Too many incorrect attempts. Card retained. Goodbye.");
            return;
        }

        boolean running = true;
        while (running) {
            showMenu();
            int choice = readMenuChoice();

            switch (choice) {
                case 1:
                    handleBalanceCheck();
                    break;
                case 2:
                    handleDeposit();
                    break;
                case 3:
                    handleWithdrawal();
                    break;
                case 4:
                    System.out.println("Thank you for banking with us. Goodbye!");
                    running = false;
                    break;
                default:
                    System.out.println("Invalid option. Please choose 1-4.");
            }
        }
        scanner.close();
    }

    // ---------- Authentication (Security Gate) ----------
    private boolean authenticate() {
        int attempts = 0;
        while (attempts < 3) {
            System.out.print("Enter your 4-digit PIN: ");

            // Guard against non-integer input crashing the Scanner
            while (!scanner.hasNextInt()) {
                System.out.println("Invalid input. PIN must be numeric.");
                scanner.next(); // clear the bad token from the buffer
                System.out.print("Enter your 4-digit PIN: ");
            }

            int enteredPin = scanner.nextInt();
            if (account.validatePin(enteredPin)) {
                System.out.println("Authentication successful.\n");
                return true;
            } else {
                attempts++;
                System.out.println("Incorrect PIN. Attempts remaining: " + (3 - attempts));
            }
        }
        return false;
    }

    // ---------- Menu ----------
    private void showMenu() {
        System.out.println("\n---------- MAIN MENU ----------");
        System.out.println("1. Check Balance");
        System.out.println("2. Deposit");
        System.out.println("3. Withdraw");
        System.out.println("4. Exit");
        System.out.print("Choose an option: ");
    }

    private int readMenuChoice() {
        while (!scanner.hasNextInt()) {
            System.out.println("Please enter a valid number (1-4).");
            scanner.next();
            System.out.print("Choose an option: ");
        }
        return scanner.nextInt();
    }

    // ---------- Transaction handlers ----------
    private void handleBalanceCheck() {
        System.out.printf("Your current balance is: $%.2f%n", account.getBalance());
    }

    private void handleDeposit() {
        double amount = readValidAmount("Enter amount to deposit: $");
        if (account.deposit(amount)) {
            System.out.printf("Deposit successful. New balance: $%.2f%n", account.getBalance());
        } else {
            System.out.println("Deposit failed. Amount must be greater than zero.");
        }
    }

    private void handleWithdrawal() {
        double amount = readValidAmount("Enter amount to withdraw: $");
        if (account.withdraw(amount)) {
            System.out.printf("Withdrawal successful. New balance: $%.2f%n", account.getBalance());
        } else {
            System.out.println("Withdrawal failed. Check that the amount is valid and does not exceed your balance.");
        }
    }

    /**
     * Robust numeric input reader (the "Security Gate").
     * Uses hasNextDouble() to peek before consuming, so bad input
     * (letters, symbols) never crashes the program.
     */
    private double readValidAmount(String prompt) {
        System.out.print(prompt);
        while (!scanner.hasNextDouble()) {
            System.out.println("Invalid input. Please enter a numeric amount.");
            scanner.next(); // clear invalid token
            System.out.print(prompt);
        }
        return scanner.nextDouble();
    }
}
